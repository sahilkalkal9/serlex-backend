import mongoose from "mongoose";

const meetingSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    personName: {
      type: String,
      required: true,
      trim: true,
    },
    designation: {
      type: String,
      default: "",
      trim: true,
    },
    experienceYears: {
      type: Number,
      default: 0,
    },
    rating: {
      type: Number,
      default: 0,
    },
    reviewsCount: {
      type: Number,
      default: 0,
    },
    companyName: {
      type: String,
      default: "",
      trim: true,
    },
    description: {
      type: String,
      default: "",
    },
    location: {
      type: String,
      default: "",
    },
    startTime: {
      type: Date,
      required: true,
    },
    endTime: {
      type: Date,
      required: true,
    },
    attendees: [
      {
        email: { type: String, trim: true, lowercase: true },
      },
    ],
    avatarUrl: {
      type: String,
      default: "",
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    googleEventId: {
      type: String,
      default: "",
    },
    googleCalendarId: {
      type: String,
      default: "primary",
    },
    source: {
      type: String,
      enum: ["manual", "google"],
      default: "google",
    },
    status: {
      type: String,
      enum: ["upcoming", "ongoing", "completed", "cancelled"],
      default: "upcoming",
    },
    startLocation: {
      type: {
        lat: { type: Number },
        lng: { type: Number },
        name: { type: String, default: "" },
      },
      default: null,
    },
    endLocation: {
      type: {
        lat: { type: Number },
        lng: { type: Number },
        name: { type: String, default: "" },
      },
      default: null,
    },
    hasReport: {
      type: Boolean,
      default: false,
    },
    approvalStatus: {
      type: String,
      enum: ["pending", "approved", "rejected"],
      default: "pending",
    },
    cancellationRemark: {
      type: String,
      default: "",
      trim: true,
    },
    meetingType: {
      type: String,
      enum: ["client", "team"],
      default: "client",
    },
    attendeeResponses: [
      {
        email: {
          type: String,
          trim: true,
          lowercase: true,
        },
        status: {
          type: String,
          enum: ["pending", "approved", "rejected"],
          default: "pending",
        },
        rejectionReason: {
          type: String,
          default: "",
          trim: true,
        },
        respondedAt: {
          type: Date,
          default: null,
        },
        respondedBy: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
          default: null,
        },
      },
    ],

    cancelledBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    cancellationRemark: {
      type: String,
      default: "",
      trim: true,
    },

    isFollowUp: {
      type: Boolean,
      default: false,
    },

    leadId: {
      type: String,
      default: "",
      trim: true,
    },

    followUpRemark: {
      type: String,
      default: "",
      trim: true,
    },
  },
  { timestamps: true }
);

const Meeting = mongoose.model("Meeting", meetingSchema);

export default Meeting;